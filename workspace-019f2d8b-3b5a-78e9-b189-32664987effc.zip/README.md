# Luna Fashion Design

Elegant Fashion for Modern Women — A premium fashion e-commerce experience.

This is a fully functional, self-contained single-page website featuring:

- Hero section with beautiful runway imagery
- Curated product collection with filters & sorting
- Interactive product modals
- Fully working shopping cart + checkout
- Virtual Atelier Concierge quiz
- Lookbook experience
- Global boutiques section

## Live Demo

Once deployed via GitHub Pages, your site will be available at:  
`https://your-username.github.io/luna-fashion-design`

## How to Deploy on GitHub (Step-by-step)

### 1. Create a GitHub Repository

1. Go to [github.com](https://github.com) and sign in.
2. Click the **"+"** icon → **New repository**.
3. Name it: `luna-fashion-design` (or any name you prefer)
4. Keep it **Public**
5. **Do NOT** initialize with README (we'll push our own)
6. Click **Create repository**

### 2. Prepare and Push Your Code

Open your terminal and run these commands:

```bash
# 1. Navigate to the project folder
cd /path/to/your/project

# 2. Initialize git
git init

# 3. Add all files
git add .

# 4. Commit
git commit -m "Initial commit: Luna Fashion Design website"

# 5. Add your GitHub repository as remote (replace YOUR_USERNAME)
git remote add origin https://github.com/YOUR_USERNAME/luna-fashion-design.git

# 6. Push to GitHub
git branch -M main
git push -u origin main
```

### 3. Enable GitHub Pages

1. Go to your new repository on GitHub.
2. Click **Settings** tab.
3. Scroll down to **Pages** section.
4. Under **Source**, select **Deploy from a branch**.
5. Choose branch: `main`
6. Folder: `/ (root)`
7. Click **Save**.

Your site will be live in ~1 minute at:  
`https://YOUR_USERNAME.github.io/luna-fashion-design`

---

## Project Structure

```
luna-fashion-design/
├── index.html          # Main website (fully self-contained)
├── README.md           # This file
```

## Customization

- Edit `index.html` directly to make changes.
- All styles, scripts, and images are included inline.
- The site works offline and requires no build step.

## Need Help?

If you want me to:
- Add a custom domain
- Add more products
- Change branding/colors
- Add backend features (later)

Just let me know!

---

**Built with ❤️ using modern web technologies**